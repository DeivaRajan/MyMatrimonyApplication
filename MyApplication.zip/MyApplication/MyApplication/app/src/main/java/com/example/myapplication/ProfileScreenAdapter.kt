package com.example.myapplication

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.databinding.AdapterHomeScreenBinding
import com.example.myapplication.databinding.AdapterProfileBinding

class ProfileScreenAdapter(
    private val context: Context?,

    ) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private lateinit var binding: AdapterProfileBinding
    private var dataList = ArrayList<HashMap<String, String>>()
    private lateinit var onItemClickListener: OnAssetItemClickListener


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        binding= DataBindingUtil.inflate(LayoutInflater.from(context),
            R.layout.adapter_profile, parent, false)
        return MyViewHolder(binding.root)
    }

    inner class MyViewHolder(itemView: View) :
        RecyclerView.ViewHolder(itemView) {
        private val tvProfile = binding.profileimg

    }
    fun setOnItemClickListener(clickListener: OnAssetItemClickListener) {
        this.onItemClickListener = clickListener
    }


    fun setList(list: ArrayList<HashMap<String, String>>){
        dataList = list as  ArrayList<HashMap<String, String>>
        notifyDataSetChanged()
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val dataViewHolder = holder as MyViewHolder
//        val data = dataList[position]
//        dataViewHolder.bindView(data)
    }

    override fun getItemCount(): Int {
        return 6
    }
}
