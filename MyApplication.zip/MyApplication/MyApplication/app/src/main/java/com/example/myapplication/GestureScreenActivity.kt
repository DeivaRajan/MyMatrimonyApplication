package com.example.myapplication

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication.databinding.ActivityGestureBinding

class GestureScreenActivity : AppCompatActivity(),OnAssetItemClickListener {
    private lateinit var binding: ActivityGestureBinding
    private lateinit var GestureAdapter: GestureScreenAdapter
    var dataList = ArrayList<HashMap<String, String>>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGestureBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val dataList = intent .getSerializableExtra( "key" )
        Log.d("wwg",""+dataList.toString())
        //Log.d("www",""+dataList[0].toString())
        GestureAdapter = GestureScreenAdapter(this)
        val layoutManager = LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false)
        layoutManager.reverseLayout = false
        binding.gestureClassList.layoutManager = layoutManager
        binding.gestureClassList.adapter = GestureAdapter
        GestureAdapter.setOnItemClickListener(this)
        loadIntoList()
        binding.toolbar.backArrow.setOnClickListener{
            onBackPressed()
        }
    }
    @SuppressLint("Range")
    fun loadIntoList() {
        dataList.clear()
        val db = MHelper(this, null)
        val cursor = db.getName()
        cursor!!.moveToFirst()

        while (!cursor.isAfterLast) {
            val map = HashMap<String, String>()
            map["id"] = cursor.getString(cursor.getColumnIndex(MHelper.ID_COL))
            map["name"] = cursor.getString(cursor.getColumnIndex(MHelper.NAME_COl))
            map["age"] = cursor.getString(cursor.getColumnIndex(MHelper.AGE_COL))
            dataList.add(map)

            cursor.moveToNext()
        }
        Log.d("www", "" + dataList.toString())
        GestureAdapter.setList(dataList)
    }
    override fun onAssetClick(data: HashMap<String, String>) {
        Toast.makeText(this,   " yes", Toast.LENGTH_LONG).show()
    }

    override fun onNoClick(data: String?) {
        val db = MHelper(this, null)
        Log.d("sss",""+data)
        db.deleteCourse(data.toString())
        loadIntoList()

        Toast.makeText(this, " removed from database", Toast.LENGTH_LONG).show()

    }
}
