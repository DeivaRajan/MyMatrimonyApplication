package com.example.myapplication

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity(), OnAssetItemClickListener {
    private lateinit var binding: ActivityMainBinding
   private lateinit var homeAdapter: HomescreenAdapter
    var dataList = ArrayList<HashMap<String, String>>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        homeAdapter = HomescreenAdapter(this)
        val layoutManager = LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false)
        layoutManager.reverseLayout = false
        binding.homeClassList.layoutManager = layoutManager
        binding.homeClassList.adapter = homeAdapter
        homeAdapter.setOnItemClickListener(this)
        valueone()
//       // dbHandler.deleteRow("1")
        loadIntoList()
        binding.threedots.setOnClickListener {
             navigateGeature()


        }
    }

    private fun navigateGeature() {
        val intent = Intent(this, GestureScreenActivity::class.java)
            intent.putExtra("key", dataList)
        startActivity(intent)
    }

    private fun valueone(){
        val name = "Kirithiga_i"
        val age = "25Yrs,5ft 2 inches,Star- Poosam,MBBS - Doctor,chennai,Tamil nadu"
        val db = MHelper(this, null)
        db.addName(name, age)

        // Toast to message on the screen
        Toast.makeText(this, name + " added to database", Toast.LENGTH_LONG).show()



       // finish()
    }
//

    @SuppressLint("Range")
    fun loadIntoList(){
        dataList.clear()
        val db = MHelper(this, null)

        // below is the variable for cursor
        // we have called method to get
        // all names from our database
        // and add to name text view
        val cursor = db.getName()
        cursor!!.moveToFirst()

        while (!cursor.isAfterLast) {
            val map = HashMap<String, String>()
            map["id"] =  cursor.getString(cursor.getColumnIndex(MHelper.ID_COL))
            map["name"] = cursor.getString(cursor.getColumnIndex(MHelper.NAME_COl))
            map["age"] = cursor.getString(cursor.getColumnIndex(MHelper.AGE_COL))
            dataList.add(map)

            cursor.moveToNext()
        }
        Log.d("www",""+dataList.toString())
        homeAdapter.setList(dataList)
       // binding.Name.text= data.getValue(0.toString())


    }

    override fun onAssetClick(data: HashMap<String, String>) {
        val intent = Intent(this, ProfileScreenActivity::class.java)
        intent.putExtra("key", data)
        startActivity(intent)
    }

    override fun onNoClick(data: String?) {
        val db = MHelper(this, null)
        Log.d("sss",""+data)
        db.deleteCourse(data.toString())
        Log.d("sss",""+dataList.toString())
        loadIntoList()

        Toast.makeText(this, " removed from database", Toast.LENGTH_LONG).show()
}
}