package com.example.myapplication

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.databinding.AdapterGestureScreenBinding
import com.example.myapplication.databinding.AdapterHomeScreenBinding

class GestureScreenAdapter(
    private val context: Context?,

    ) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private lateinit var binding: AdapterGestureScreenBinding
    private lateinit var onItemClickListener: OnAssetItemClickListener
    private var dataList = ArrayList<HashMap<String, String>>()


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        binding= DataBindingUtil.inflate(LayoutInflater.from(context),
            R.layout.adapter_gesture_screen, parent, false)
        return MyViewHolder(binding.root)
    }

    inner class MyViewHolder(itemView: View) :
        RecyclerView.ViewHolder(itemView) {
        private val tvName= binding.name
        private val tvDetails= binding.textDetails
        private val tvbtnno = binding.btnNo
        fun bindView(data: HashMap<String, String>) {
            tvName.text = data["name"]
            tvDetails.text = data["age"]

            tvbtnno.setOnClickListener {
                onItemClickListener.onNoClick(data["id"])
            }
        }

    }
    fun setOnItemClickListener(clickListener: OnAssetItemClickListener) {
        this.onItemClickListener = clickListener
    }

    fun setList(list: ArrayList<HashMap<String, String>>){
        dataList = list as  ArrayList<HashMap<String, String>>
        notifyDataSetChanged()
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val dataViewHolder = holder as MyViewHolder
        val data = dataList[position]
        dataViewHolder.bindView(data)
    }

    override fun getItemCount(): Int {
        return dataList.size
    }
}
