package com.example.myapplication

import java.util.HashMap

interface OnAssetItemClickListener {
    fun onAssetClick(data: HashMap<String, String>)
    fun onNoClick(data: String?)
}
