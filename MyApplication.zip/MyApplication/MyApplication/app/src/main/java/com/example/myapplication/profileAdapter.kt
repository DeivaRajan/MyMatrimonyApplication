package com.example.myapplication

class profileAdapter {
}