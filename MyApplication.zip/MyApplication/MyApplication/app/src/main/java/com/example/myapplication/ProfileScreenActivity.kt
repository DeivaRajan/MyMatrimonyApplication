package com.example.myapplication

import android.os.Bundle
import android.util.Log
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.viewpager.widget.ViewPager
import com.example.myapplication.databinding.ActivityGestureBinding
import com.example.myapplication.databinding.ActivityProfileBinding

class ProfileScreenActivity : AppCompatActivity(), ViewPager.OnPageChangeListener {
    private lateinit var binding: ActivityProfileBinding
    private lateinit var profileAdapter: ProfileScreenAdapter
    private lateinit var dots: Array<TextView?>
    private  var layouts: Int = 6
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val dataList = intent .getSerializableExtra( "key" )
        Log.d("wwg",""+dataList.toString())
        init(dataList as HashMap<String, String>)
       binding.toolbar.backArrow.setOnClickListener{
           onBackPressed()
       }
       profileAdapter = ProfileScreenAdapter(this)
       val layoutManager = LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false)
       layoutManager.reverseLayout = false
       binding.profilelist.layoutManager = layoutManager
       binding.profilelist.adapter = profileAdapter
        addBottomDots(0)
    //Log.d("www",""+dataList[0].toString())
//        GestureAdapter = GestureScreenAdapter(this)
//        val layoutManager = LinearLayoutManager(this)
//        layoutManager.reverseLayout = true
//        binding.gestureClassList.layoutManager = layoutManager
//        binding.gestureClassList.adapter = GestureAdapter
//        GestureAdapter.setList(dataList as ArrayList<HashMap<String, String>>)

    }

    private fun addBottomDots(currentPage: Int) {
        dots = arrayOfNulls(layouts)
        binding.layoutDots.removeAllViews()
        for (i in dots.indices) {
            val params: LinearLayout.LayoutParams =
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT)
            params.setMargins(10, 10, 10, 10)
            dots[i] = TextView(this)
            dots[i]!!.height = 5
            dots[i]!!.width = 5
            dots[i]!!.layoutParams = params
            dots[i]!!.background = ContextCompat.getDrawable(this, R.drawable.page_indicator)
            dots[i]!!.isEnabled = false
            binding.layoutDots.addView(dots[i])
        }
        if (dots.isNotEmpty()) {
            dots[currentPage]!!.isEnabled = true
        }
    }
    private fun init(data: HashMap<String, String>){
        binding.name.text = data["name"]
        binding.textDetails.text = data["age"]

    }

    override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
        addBottomDots(position)
    }

    override fun onPageSelected(position: Int) {

    }

    override fun onPageScrollStateChanged(state: Int) {

    }
}